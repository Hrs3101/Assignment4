func myfunc1()
{ 

 var arr = [4,2,3,1,5]
let l = arr.count
print(l)
 arr.sort()

 print(arr[])
}
myfunc1()
